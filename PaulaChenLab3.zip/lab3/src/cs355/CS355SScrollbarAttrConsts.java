/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cs355;

/**
 *
 * @author Talonos
 */
enum CS355SScrollbarAttrConsts 
{
    V_SCROLL_BAR, H_SCROLL_BAR, MIN, MAX, KNOB, POSIT
}
