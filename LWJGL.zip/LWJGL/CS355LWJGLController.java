package CS355.LWJGL;

/**
 *
 * @author Brennan Smith
 */
public interface CS355LWJGLController {

    void render();

    void resizeGL();

    void update();

    void updateKeyboard();
    
}
